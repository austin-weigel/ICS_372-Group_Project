/**
 * 
 * @author Brodsky R, Schreifels J, Vang J, Weigel A
 *
 */
public interface Visitor {
	public String visit(Donation item);
}
